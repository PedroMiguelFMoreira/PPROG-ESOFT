package listatelefonica.ui.consola;

import listatelefonica.utils.Utils;
import listatelefonica.model.ListaTelefonica;
import listatelefonica.controllers.AdicionarTelefoneController;

public class AdicionarTelefoneUI {

    private ListaTelefonica listaTelefonica;
    private AdicionarTelefoneController controller;

    public AdicionarTelefoneUI(ListaTelefonica listaTelefonica) {
        this.listaTelefonica = listaTelefonica;
        this.controller = new AdicionarTelefoneController(this.listaTelefonica);
    }

    public void run() {
        
        try {
            
            this.controller.novoTelefone();

            String titular = Utils.readLineFromConsole("Titular:");
            int numero = Integer.parseInt(Utils.readLineFromConsole("Número:"));

            this.controller.setDados(titular, numero);

            if (Utils.confirma("Confirma os dados (S/N)?")) {
                
                if (!this.controller.registaTelefone()) {
                    System.out.println("Erro ao registar telefone.");
                } else {
                    System.out.println("Telefone registado com sucesso.");
                }
            }
            
        } catch (NumberFormatException ex) {
            System.out.println("Erro: número é inválido (9 dígitos)!");
        } catch (IllegalArgumentException ex) {
            System.out.println("Erro:" + ex.getMessage());
        }

    }
}
