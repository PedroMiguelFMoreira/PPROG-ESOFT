package listatelefonica.ui.grafica;

import java.io.File;
import javax.swing.UIManager;
import javax.swing.JFileChooser;
import javax.swing.filechooser.FileFilter;

public class MyJFileChooser extends JFileChooser {
    
    public MyJFileChooser() {
        super();
        definirFiltroExtensaoBin();
    }
    
    private void definirFiltroExtensaoBin(){
        
        this.setFileFilter(new FileFilter() {
           
            @Override
            public boolean accept(File ficheiro) {
                
                if (ficheiro.isDirectory()) {
                    return true;
                }
                
                String extensao = extensao(ficheiro);
                
                if (extensao != null) {
                    return extensao.equals("bin");
                }
                
                return false;
            }

            @Override
            public String getDescription() {
                return "*.bin";
            }

            private String extensao(File ficheiro) {
                
                String extensao = null;
                
                String nomeFicheiro = ficheiro.getName();
                
                int indice = nomeFicheiro.lastIndexOf(".");
                
                if (indice != -1) {
                    extensao = nomeFicheiro.substring(indice + 1).toLowerCase();
                }
                
                return extensao;
            }
        });
    }     

    public static void personalizarFileChooserEmPortugues() {

        // Títulos das Caixas de Diálogo
        UIManager.put("FileChooser.openDialogTitleText", "Importar Lista Telefónica");
        UIManager.put("FileChooser.saveDialogTitleText", "Exportar Lista Telefónica");

        // Botão "Importar"
        UIManager.put("FileChooser.openButtonText", "Importar");
        UIManager.put("FileChooser.openButtonMnemonic", "I");
        UIManager.put("FileChooser.openButtonToolTipText", "Importar Lista Telefónica");

        // Botão "Exportar"
        UIManager.put("FileChooser.saveButtonText", "Exportar");
        UIManager.put("FileChooser.saveButtonMnemonic", "E");
        UIManager.put("FileChooser.saveButtonToolTipText", "Exportar Lista Telefónica");

        // Botão "Cancelar"
        UIManager.put("FileChooser.cancelButtonText", "Cancelar");
        UIManager.put("FileChooser.cancelButtonMnemonic", "C");
        UIManager.put("FileChooser.cancelButtonToolTipText", "Cancelar");

        // Botão "Ajuda"
        UIManager.put("FileChooser.helpButtonText", "Ajuda");
        UIManager.put("FileChooser.helpButtonMnemonic", "A");
        UIManager.put("FileChooser.helpButtonToolTipText", "Ajuda");

        // Legenda "Procurar em:"
        UIManager.put("FileChooser.lookInLabelText", "Procurar em:");
        UIManager.put("FileChooser.lookInLabelMnemonic", "E");

        // Legenda "Guardar em:"
        UIManager.put("FileChooser.saveInLabelText", "Guardar em:");
        UIManager.put("FileChooser.saveInLabelMnemonic", "G");

        // Legenda "Tipo de ficheiros:"
        UIManager.put("FileChooser.filesOfTypeLabelText", "Ficheiros do tipo:");
        UIManager.put("FileChooser.filesOfTypeLabelMnemonic", "F");

        // Legenda "Nome do ficheiro:"
        UIManager.put("FileChooser.fileNameLabelText", "Nome do ficheiro:");
        UIManager.put("FileChooser.fileNameLabelMnemonic", "N");

        // Filtro "Todos os Ficheiros"
        UIManager.put("FileChooser.acceptAllFileFilterText", "Todos os Ficheiros");

        // Botão "Um nível acima"
        UIManager.put("FileChooser.upFolderAccessibleName", "Um nível acima");
        UIManager.put("FileChooser.upFolderToolTipText", "Um nível acima");

        // Botão "Ambiente de Trabalho"
        UIManager.put("FileChooser.homeFolderAccessibleName", "Ambiente de Trabalho");
        UIManager.put("FileChooser.homeFolderToolTipText", "Ambiente de Trabalho");

        // Botão "Nova Pasta"
        UIManager.put("FileChooser.newFolderAccessibleName", "Criar nova pasta");
        UIManager.put("FileChooser.newFolderToolTipText", "Criar nova pasta");

        // Botão "Vista Lista"
        UIManager.put("FileChooser.listViewButtonAccessibleName", "Lista");
        UIManager.put("FileChooser.listViewButtonToolTipText", "Lista");

        // Botão "Vista Detalhada"
        UIManager.put("FileChooser.detailsViewButtonAccessibleName", "Detalhes");
        UIManager.put("FileChooser.detailsViewButtonToolTipText", "Detalhes");

        // Cabeçalhos da "Vista Lista Detalhada"
        UIManager.put("FileChooser.fileNameHeaderText", "Nome");
        UIManager.put("FileChooser.fileSizeHeaderText", "Tamanho");
        UIManager.put("FileChooser.fileTypeHeaderText", "Tipo");
        UIManager.put("FileChooser.fileDateHeaderText", "Data");
        UIManager.put("FileChooser.fileAttrHeaderText", "Atributos");
    }

}
