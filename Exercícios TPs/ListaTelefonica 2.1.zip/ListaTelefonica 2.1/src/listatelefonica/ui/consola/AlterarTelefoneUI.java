package listatelefonica.ui.consola;

import java.util.List;
import listatelefonica.utils.Utils;
import listatelefonica.model.Telefone;
import listatelefonica.model.ListaTelefonica;
import listatelefonica.controllers.AlterarTelefoneController;

public class AlterarTelefoneUI {

    private ListaTelefonica listaTelefonica;
    private AlterarTelefoneController controller;

    public AlterarTelefoneUI(ListaTelefonica listaTelefonica) {
        this.listaTelefonica = listaTelefonica;
        this.controller = new AlterarTelefoneController(this.listaTelefonica);
    }

    public void run() {
        
        try {
            
            List<Telefone> telefones = this.controller.getListaTelefones();
            
            Telefone telefoneEditado = (Telefone) Utils.apresentaESeleciona(
                    telefones,
                    "Selecione o telefone a alterar:");
            
            if (telefoneEditado != null) {
                
                if (this.controller.editaTelefone(telefoneEditado.getNumero())) {
                    
                    String titular = Utils.readLineFromConsole("Novo Titular:");
                    
                    int numero = Integer.parseInt(
                            Utils.readLineFromConsole("Novo Número:"));
                    
                    if (this.controller.alteraDados(titular, numero)) {
                        System.out.println("Telefone alterado com sucesso.");
                    } else {
                        System.out.println("Erro ao alterar telefone.");
                    }
                }
            }
        } catch (NumberFormatException ex) {
            System.out.println("Erro: número é inválido (9 dígitos)!");
        } catch (IllegalArgumentException ex) {
            System.out.println("Erro:" + ex.getMessage());
        }
    }
}
