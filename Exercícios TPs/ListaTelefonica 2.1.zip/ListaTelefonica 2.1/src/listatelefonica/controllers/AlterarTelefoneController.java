package listatelefonica.controllers;

import java.util.List;
import listatelefonica.model.Telefone;
import listatelefonica.model.ListaTelefonica;

public class AlterarTelefoneController {

    private ListaTelefonica listaTelefonica;
    private Telefone telefone;

    public AlterarTelefoneController(ListaTelefonica listaTelefonica) {
        this.listaTelefonica = listaTelefonica;
        this.telefone = null;
    }

    public List<Telefone> getListaTelefones() {
        return this.listaTelefonica.getListaTelefonica();
    }

    public boolean editaTelefone(int numero) {
        this.telefone = this.listaTelefonica.getTelefonePorNumero(numero);
        return (this.telefone != null);
    }

    public boolean alteraDados(String titular, int numero) {
        try {

            if (this.telefone != null) {

                Telefone telefoneAlterado = (Telefone) this.telefone.clone();

                telefoneAlterado.setTitular(titular);
                telefoneAlterado.setNumero(numero);

                return this.listaTelefonica
                        .updateTelefone(this.telefone, telefoneAlterado);
            }

            return false;

        } catch (IllegalArgumentException ex) {
            return false;
        }
    }
}
