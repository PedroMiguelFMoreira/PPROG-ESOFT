package listatelefonica.controllers;

import listatelefonica.model.Telefone;
import listatelefonica.model.ListaTelefonica;

public class AdicionarTelefoneController {

    private ListaTelefonica listaTelefonica;
    private Telefone telefone;

    public AdicionarTelefoneController(ListaTelefonica listaTelefonica) {
        this.listaTelefonica = listaTelefonica;
        this.telefone = null;
    }

    public boolean setDados(String titular, int numero) {

        if (this.telefone != null) {
            this.telefone.setTitular(titular);
            this.telefone.setNumero(numero);
            return true;
        }

        return false;
    }

    public void novoTelefone() {
        this.telefone = this.listaTelefonica.novoTelefone();
    }

    public boolean registaTelefone() {

        if (this.telefone != null) {

            boolean telefoneAdicionado
                    = this.listaTelefonica.adicionarTelefone(this.telefone);

            if (telefoneAdicionado) {
                this.telefone = null;
            }

            return telefoneAdicionado;
        }

        return false;
    }
}
