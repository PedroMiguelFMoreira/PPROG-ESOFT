package listatelefonica.utils;

import java.util.List;
import java.util.Scanner;

public class Utils
{
    public static String readLineFromConsole(String prompt)
    {
        System.out.println(prompt);
        
        Scanner ler = new Scanner(System.in);
        return ler.nextLine();
    }
        
    public static boolean confirma(String message) {
        String confirma;
        do {
            confirma = Utils.readLineFromConsole("\n" + message + "\n");
        } while (!confirma.equalsIgnoreCase("s") && !confirma.equalsIgnoreCase("n"));

        return confirma.equalsIgnoreCase("s");
    }
    
    public static Object apresentaESeleciona(List list,String header)
    {
        apresentaLista(list,header);
        System.out.println();
        System.out.println("0 - Cancelar");
        return selecionaObject(list);
    }
    
    public static void apresentaLista(List list,String header)
    {
        System.out.println(header);

        if (list.isEmpty()) {
            System.out.println("(vazia)");
        } else {
            int index = 0;
            for (Object obj : list) {
                index++;
                System.out.println(index + ". " + obj.toString());
            }
        }
        
    }
    
    public static Object selecionaObject(List list)
    {
        String opcao;
        int nOpcao = -1;
        boolean opcaoInvalida;
        do
        {
            opcaoInvalida = false;
            
            try{
                opcao = Utils.readLineFromConsole("Introduza opção: ");
                nOpcao = new Integer(opcao);
                
                opcaoInvalida = nOpcao < 0 || nOpcao > list.size();
                if(opcaoInvalida)
                    Utils.readLineFromConsole(
                            "Opção inválida!\nPrima ENTER para continuar.");
                
            } catch(NumberFormatException ex){
                Utils.readLineFromConsole(
                        "Opção inválida!\nPrima ENTER para continuar.");
                opcaoInvalida = true;
            }
            
        } while (opcaoInvalida);

        return (nOpcao == 0) ? null : list.get(nOpcao - 1);
    }
}
