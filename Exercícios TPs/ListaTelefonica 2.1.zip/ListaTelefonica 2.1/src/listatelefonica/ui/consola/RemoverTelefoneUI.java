package listatelefonica.ui.consola;

import java.util.List;
import listatelefonica.utils.Utils;
import listatelefonica.model.Telefone;
import listatelefonica.model.ListaTelefonica;
import listatelefonica.controllers.RemoverTelefoneController;

public class RemoverTelefoneUI {

    private ListaTelefonica listaTelefonica;
    private RemoverTelefoneController controller;

    public RemoverTelefoneUI(ListaTelefonica listaTelefonica) {
        this.listaTelefonica = listaTelefonica;
        this.controller = new RemoverTelefoneController(this.listaTelefonica);
    }

    public void run() {
        
        List<Telefone> telefones = controller.getListaTelefones();

        Telefone telefoneARemover = (Telefone) Utils.apresentaESeleciona(
                telefones,
                "Selecione o telefone a eliminar:");
        
        if (telefoneARemover != null) {
            
            if (Utils.confirma("Confirma a eliminação do telefone selecionado (S/N)?")) {
                
                if (this.controller.removeTelefone(telefoneARemover)) {
                    System.out.println("Telefone eliminado com sucesso.");
                } else {
                    System.out.println("Erro: Não foi possivel eliminar o telefone.");
                }
                
            }
            
        }
    }
}
