package listatelefonica.ui.consola;

import java.util.List;
import listatelefonica.utils.Utils;
import listatelefonica.model.Telefone;
import listatelefonica.model.ListaTelefonica;
import listatelefonica.controllers.AlterarTelefoneController;

public class VerListaTelefonicalUI {

    private ListaTelefonica listaTelefonica;
    private AlterarTelefoneController controller;

    public VerListaTelefonicalUI(ListaTelefonica listaTelefonica) {
        this.listaTelefonica = listaTelefonica;
        this.controller = new AlterarTelefoneController(this.listaTelefonica);
    }

    public void run() {
        List<Telefone> telefones = this.controller.getListaTelefones();
        Utils.apresentaLista(telefones, "\nLista Telefónica");
    }
}
