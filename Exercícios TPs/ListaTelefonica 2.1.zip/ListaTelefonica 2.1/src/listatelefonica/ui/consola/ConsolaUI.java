package listatelefonica.ui.consola;

import listatelefonica.utils.Utils;
import listatelefonica.model.ListaTelefonica;
import listatelefonica.controllers.ExportarListaTelefonicaController;

public class ConsolaUI {

    private ListaTelefonica listaTelefonica;

    public ConsolaUI(ListaTelefonica listaTelefonica) {
        this.listaTelefonica = listaTelefonica;
    }

    public void run() {
        
        String opcao;
        boolean sair = false;
        
        do {
            
            System.out.println("\n------------------------\n");
            System.out.println("Menu Principal:\n");
            System.out.println("1. Ver Lista Telefónica");
            System.out.println("2. Novo Telefone");
            System.out.println("3. Alterar Telefone");
            System.out.println("4. Eliminar Telefone");
            System.out.println("5. Importar Lista Telefónica");
            if (!this.listaTelefonica.isVazio()) {
                System.out.println("6. Exportar Lista Telefónica");
            }
            System.out.println("0. Sair");

            opcao = Utils.readLineFromConsole("Introduza opção: ");

            switch (opcao) {
                case "1": {
                    VerListaTelefonicalUI ui
                            = new VerListaTelefonicalUI(this.listaTelefonica);
                    ui.run();
                    break;
                }
                case "2": {
                    AdicionarTelefoneUI ui
                            = new AdicionarTelefoneUI(this.listaTelefonica);
                    ui.run();
                    break;
                }
                case "3": {
                    AlterarTelefoneUI ui
                            = new AlterarTelefoneUI(this.listaTelefonica);
                    ui.run();
                    break;
                }
                case "4": {
                    RemoverTelefoneUI ui
                            = new RemoverTelefoneUI(this.listaTelefonica);
                    ui.run();
                    break;
                }
                case "5": {
                    ImportarListaTelefonicaUI ui
                            = new ImportarListaTelefonicaUI(this.listaTelefonica);
                    ui.run();
                    break;
                }
                case "6": {
                    ExportarListaTelefonicaUI ui
                            = new ExportarListaTelefonicaUI(this.listaTelefonica);
                    ui.run();
                    break;
                }
                case "0":
                    sair = true;
                    break;
                default:
                    System.out.println("\nOpção Inválida!");
            }

            if(!sair)
                Utils.readLineFromConsole("\nPrima ENTER para continuar.");
        } while (!sair);

        ExportarListaTelefonicaController controller
                = new ExportarListaTelefonicaController();

        boolean listaTelefonicaGuardada
                = controller.exportarListaTelefonica(this.listaTelefonica);

        if (!listaTelefonicaGuardada) {
            System.out.println("Impossível guardar lista telefónica!");
        }
    }
}
