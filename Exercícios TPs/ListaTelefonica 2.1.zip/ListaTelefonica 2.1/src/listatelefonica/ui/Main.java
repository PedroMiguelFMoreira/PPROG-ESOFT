package listatelefonica.ui;

import javax.swing.JOptionPane;
import listatelefonica.ui.grafica.Janela;
import listatelefonica.ui.consola.ConsolaUI;
import listatelefonica.model.ListaTelefonica;
import listatelefonica.controllers.ImportarListaTelefonicaController;

public class Main {

    public static void main(String[] args) {

        ListaTelefonica listaTelefonica = new ListaTelefonica();

        ImportarListaTelefonicaController controller
                = new ImportarListaTelefonicaController(listaTelefonica);
        controller.importarListaTelefonica();

        String[] opcoes = {"Ambiente Gráfico", "Ambiente Consola"};
        int resposta = JOptionPane.showOptionDialog(
                null,
                "Selecione o ambiente de execução",
                "Ambiente de execução",
                0,
                JOptionPane.QUESTION_MESSAGE,
                null,
                opcoes,
                opcoes[0]);

        final int AMBIENTE_GRAFICO = 0;
        if (resposta == AMBIENTE_GRAFICO) {
            new Janela(listaTelefonica);
        } else {
            new ConsolaUI(listaTelefonica).run();
        }
    }

}
