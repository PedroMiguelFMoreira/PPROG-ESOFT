package listatelefonica.controllers;

import java.util.List;
import listatelefonica.model.Telefone;
import listatelefonica.model.ListaTelefonica;
import listatelefonica.model.FicheiroListaTelefonica;

public class ImportarListaTelefonicaController {

    private FicheiroListaTelefonica ficheiro;
    private ListaTelefonica listaTelefonica;

    public ImportarListaTelefonicaController(ListaTelefonica listaTelefonica) {
        this.ficheiro = new FicheiroListaTelefonica();
        this.listaTelefonica = listaTelefonica;
    }

    public int importarTelefones(List<Telefone> telefones) {

        int cont = 0;
        for (Telefone telefone : telefones) {
            if (this.listaTelefonica.adicionarTelefone(telefone)) {
                cont++;
            }
        }
        
        return cont;
    }

    public int importarListaTelefonica() {
        
        int totalRegistos = -1;
        ListaTelefonica importada = this.ficheiro.ler();

        if (importada != null) {
            totalRegistos = importarTelefones(importada.getListaTelefonica());
        }
        
        return totalRegistos;
    }

    public int importarListaTelefonica(String nomeFicheiro) {
        
        int totalRegistos = -1;
        ListaTelefonica importada = this.ficheiro.ler(nomeFicheiro);
        
        if (importada != null) {
            totalRegistos = importarTelefones(importada.getListaTelefonica());
        }
        
        return totalRegistos;
    }
}
