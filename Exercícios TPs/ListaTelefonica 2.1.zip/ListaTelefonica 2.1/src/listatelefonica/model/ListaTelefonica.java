package listatelefonica.model;

import java.util.List;
import java.util.ArrayList;
import java.util.Collections;
import java.io.Serializable;

public class ListaTelefonica implements Serializable {

    private List<Telefone> listaTelefonica;

    public ListaTelefonica() {
        this.listaTelefonica = new ArrayList<>();
    }

    public List<Telefone> getListaTelefonica() {
        return new ArrayList(this.listaTelefonica);
    }

    @Override
    public String toString() {
        
        Collections.sort(this.listaTelefonica);
        
        StringBuilder s = new StringBuilder();
        
        for (Telefone telefone : this.listaTelefonica) {
            s.append(telefone);
            s.append("\n");
        }
        
        return String.format("Lista Telefónica%n%s", s.toString());
    }

    @Override
    public boolean equals(Object outroObjeto) {

        if (this == outroObjeto) {
            return true;
        }

        if (outroObjeto == null || this.getClass() != outroObjeto.getClass()) {
            return false;
        }

        ListaTelefonica outraListaTelefonica = (ListaTelefonica) outroObjeto;

        return this.listaTelefonica
                .equals(outraListaTelefonica.getListaTelefonica());
        
    }

    public boolean removerTelefone(Telefone telefone) {
        return this.listaTelefonica.remove(telefone);
    }

    public int tamanho() {
        return this.listaTelefonica.size();
    }

    public boolean isVazio() {
        return this.listaTelefonica.isEmpty();
    }

    public Telefone novoTelefone() {
        return new Telefone();
    }

    public boolean adicionarTelefone(Telefone telefone) {
        
        if (telefone.valida()) {
            return this.listaTelefonica.contains(telefone)
                    ? false
                    : this.listaTelefonica.add(telefone);
        }
        
        return false;
    }

    public Telefone getTelefonePorNumero(int numero) {
        
        for (Telefone telefone : this.listaTelefonica) {
            
            if (telefone.getNumero() == numero) {
                return telefone;
            }
            
        }
        return null;
    }

    public boolean updateTelefone(Telefone telefone, Telefone telefoneAlterado) {
        
        if (removerTelefone(telefone)) {
            
            if (adicionarTelefone(telefoneAlterado)) {
                
                // Temos a garantia que as alterações são válidas
                // Portanto, podemos fazer as alterações
                removerTelefone(telefoneAlterado);
                telefone.setTitular(telefoneAlterado.getTitular());
                telefone.setNumero(telefoneAlterado.getNumero());
                adicionarTelefone(telefone);
                
                return true;
                
            } else {
                
                // As alterações feitas não são válidas
                // Portanto, temos que fazer rollback
                removerTelefone(telefoneAlterado);
                adicionarTelefone(telefone);
            }
        }
        return false;
    }
}
