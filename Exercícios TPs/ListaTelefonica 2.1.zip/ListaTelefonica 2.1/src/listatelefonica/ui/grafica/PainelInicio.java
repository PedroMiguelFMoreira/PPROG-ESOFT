package listatelefonica.ui.grafica;

import javax.swing.*;
import javax.swing.ImageIcon;
import java.awt.Image;
import java.awt.Graphics;
import java.awt.Dimension;

public class PainelInicio extends JPanel {

    private static final ImageIcon imageIcon = 
            new ImageIcon(PainelInicio.class.getResource("/lista telefonica.jpg"));

    public PainelInicio() {
        super();
    }

    @Override
    public void paintComponent(Graphics g) {

        super.paintComponent(g);

        Dimension dimensaoPainel = this.getSize();
        double largura = dimensaoPainel.getWidth();
        double altura = dimensaoPainel.getHeight();

        Image image1 = imageIcon.getImage()
                .getScaledInstance((int) largura, (int) altura, Image.SCALE_SMOOTH);

        Image image2 = new ImageIcon(image1).getImage();

        final int X = 0, Y = 0;
        g.drawImage(image2, X, Y, this);

    }

}
