package listatelefonica.ui.consola;

import listatelefonica.utils.Utils;
import listatelefonica.model.ListaTelefonica;
import listatelefonica.controllers.ImportarListaTelefonicaController;

public class ImportarListaTelefonicaUI {

    private ListaTelefonica listaTelefonica;
    private ImportarListaTelefonicaController controller;

    public ImportarListaTelefonicaUI(ListaTelefonica listaTelefonica) {
        this.listaTelefonica = listaTelefonica;
        this.controller = new ImportarListaTelefonicaController(this.listaTelefonica);
    }

    public void run() {
        
        String nomeFicheiro = Utils.readLineFromConsole("Nome do ficheiro a importar:");
        
        int totalRegistos = this.controller.importarListaTelefonica(nomeFicheiro);
        
        if (totalRegistos < 0) {
            System.out.println("Não foi possivel ler o ficheiro.");
        } else {
            System.out.println("Foram importados " + totalRegistos + " registos.");
        }
    }
}
