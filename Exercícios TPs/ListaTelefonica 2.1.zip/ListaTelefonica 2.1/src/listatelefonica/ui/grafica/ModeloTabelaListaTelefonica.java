package listatelefonica.ui.grafica;

import java.util.List;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import listatelefonica.model.Telefone;
import javax.swing.table.AbstractTableModel;
import listatelefonica.controllers.AlterarTelefoneController;

public class ModeloTabelaListaTelefonica extends AbstractTableModel {

    private AlterarTelefoneController controller;
    private List<Telefone> telefones;
    private JFrame janela;

    private static String[] nomesColunas = {"Titular", "Número"};

    public ModeloTabelaListaTelefonica(
            AlterarTelefoneController controller,
            JFrame janela) {

        this.controller = controller;
        this.telefones = controller.getListaTelefones();
        this.janela = janela;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {

        String nomeColuna = getColumnName(columnIndex);

        return nomeColuna.equalsIgnoreCase(
                ModeloTabelaListaTelefonica.nomesColunas[0])
                        ? this.telefones.get(rowIndex).getTitular()
                        : this.telefones.get(rowIndex).getNumero();
    }

    @Override
    public void setValueAt(Object value, int rowIndex, int columnIndex) {

        String nomeColuna = getColumnName(columnIndex);
        Telefone telefone = this.telefones.get(rowIndex);

        if (this.controller.editaTelefone(telefone.getNumero())) {

            boolean updated;

            if (nomeColuna.equalsIgnoreCase(
                    ModeloTabelaListaTelefonica.nomesColunas[0])) {

                updated = this.controller
                        .alteraDados((String) value, telefone.getNumero());

            } else {
                updated = this.controller
                        .alteraDados(telefone.getTitular(), (Integer) value);
            }

            if (!updated) {
                JOptionPane.showMessageDialog(
                        janela,
                        "Não foi possível atualizar o telefone.",
                        "Alterar Telefone",
                        JOptionPane.ERROR_MESSAGE);
            }
        }

        this.fireTableCellUpdated(rowIndex, columnIndex);
    }

    @Override
    public int getRowCount() {
        return this.telefones.size();
    }

    @Override
    public int getColumnCount() {
        return ModeloTabelaListaTelefonica.nomesColunas.length;
    }

    @Override
    public String getColumnName(int columnIndex) {
        return ModeloTabelaListaTelefonica.nomesColunas[columnIndex];
    }

    @Override
    public Class getColumnClass(int columnIndex) {
        
        if (this.telefones.isEmpty()) {
            return Object.class;
        }
        
        final int ROW_INDEX = 0;
        return getValueAt(ROW_INDEX, columnIndex).getClass();
    }

    @Override
    public boolean isCellEditable(int rowIndex, int columnIndex) {
        return true;
    }

    public void refresh() {
        this.telefones = this.controller.getListaTelefones();
        this.fireTableDataChanged();
    }

}
