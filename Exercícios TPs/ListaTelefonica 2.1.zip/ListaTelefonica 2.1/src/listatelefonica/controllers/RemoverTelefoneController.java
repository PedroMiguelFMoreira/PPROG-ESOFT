package listatelefonica.controllers;

import java.util.List;
import listatelefonica.model.Telefone;
import listatelefonica.model.ListaTelefonica;

public class RemoverTelefoneController {

    private ListaTelefonica listaTelefonica;

    public RemoverTelefoneController(ListaTelefonica listaTelefonica) {
        this.listaTelefonica = listaTelefonica;
    }

    public List<Telefone> getListaTelefones() {
        return this.listaTelefonica.getListaTelefonica();
    }

    public Telefone[] getListaTelefonesAsArray() {
        List<Telefone> lista = this.listaTelefonica.getListaTelefonica();
        return lista.toArray(new Telefone[lista.size()]);
    }

    public boolean removeTelefone(Telefone telefone) {
        return this.listaTelefonica.removerTelefone(telefone);
    }
}
