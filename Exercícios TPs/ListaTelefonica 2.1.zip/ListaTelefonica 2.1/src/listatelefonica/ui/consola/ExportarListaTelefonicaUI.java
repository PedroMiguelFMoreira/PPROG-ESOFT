package listatelefonica.ui.consola;

import listatelefonica.utils.Utils;
import listatelefonica.model.ListaTelefonica;
import listatelefonica.controllers.ExportarListaTelefonicaController;

public class ExportarListaTelefonicaUI {

    private ListaTelefonica listaTelefonica;
    private ExportarListaTelefonicaController controller;

    public ExportarListaTelefonicaUI(ListaTelefonica listaTelefonica) {
        this.listaTelefonica = listaTelefonica;
        this.controller = new ExportarListaTelefonicaController();
    }

    public void run() {
        
        String nomeFicheiro = Utils.readLineFromConsole("Nome do ficheiro a exportar:");
                
        if (this.controller.exportarListaTelefonica(nomeFicheiro, this.listaTelefonica)) {
            System.out.println("Exportação concluída com sucesso.");
        } else {
            System.out.println("Erro ao exportar para o ficheiro indicado.");
        }
    }
}
