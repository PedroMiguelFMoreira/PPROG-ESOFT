package listatelefonica.model;

import java.io.Serializable;

public class Telefone implements Comparable<Telefone>, Serializable {

    private String titular;
    private int numero;

    private static final String TITULAR_POR_OMISSAO = "";
    private static final int NUMERO_POR_OMISSAO = 0;

    public Telefone(String titular, int numero) {
        this.setTitular(titular);
        this.setNumero(numero);
    }

    public Telefone() {
        this.titular = Telefone.TITULAR_POR_OMISSAO;
        this.numero = Telefone.NUMERO_POR_OMISSAO;
    }

    public String getTitular() {
        return this.titular;
    }

    public int getNumero() {
        return this.numero;
    }

    public final void setTitular(String titular) {
        if (!validaTitular(titular)) {
            throw new IllegalArgumentException("Nome é inválido!");
        }
        this.titular = titular;
    }

    public final void setNumero(int numero) {
        if (!validaNumero(numero)) {
            throw new IllegalArgumentException("Número é inválido (9 digitos)!");
        }
        this.numero = numero;
    }

    @Override
    public String toString() {
        return String.format("%s é titular do telefone %d", this.titular, this.numero);
    }

    @Override
    public boolean equals(Object outroObjeto) {
        
        if (this == outroObjeto) {
            return true;
        }
        
        if (outroObjeto == null || this.getClass() != outroObjeto.getClass()) {
            return false;
        }
        
        Telefone outroTelefone = (Telefone) outroObjeto;

        return this.numero == outroTelefone.numero;
    }

    @Override
    public int compareTo(Telefone outroTelefone) {
        return this.numero - outroTelefone.numero;
    }

    @Override
    public Telefone clone() {
        return new Telefone(this.titular, this.numero);
    }

    public boolean valida() {
        return (validaTitular(this.titular) && validaNumero(this.numero));
    }

    protected boolean validaTitular(String titular) {
        return !(titular == null || titular.trim().isEmpty());
    }

    protected boolean validaNumero(int numero) {
        return !(numero < 100000000 || numero > 999999999);
    }

}
