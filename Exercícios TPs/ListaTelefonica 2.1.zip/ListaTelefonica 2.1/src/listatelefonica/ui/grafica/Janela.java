package listatelefonica.ui.grafica;

import java.awt.*;
import java.awt.event.*;
import java.io.File;
import javax.swing.*;
import javax.swing.event.*;
import listatelefonica.model.*;
import listatelefonica.controllers.RemoverTelefoneController;
import listatelefonica.controllers.ExportarListaTelefonicaController;
import listatelefonica.controllers.ImportarListaTelefonicaController;

public class Janela extends JFrame {

    private ListaTelefonica listaTelefonica;
    private JTable tableListaTelefonica;
    private JMenuItem menuItemEliminar, menuItemExportarLista;
    private JTabbedPane tabPane;
    private JFileChooser fileChooser;

    public Janela(ListaTelefonica listaTelefonica) {

        super("Lista Telefónica 2.1");

        this.listaTelefonica = listaTelefonica;

        tabPane = criarSeparadores();
        add(tabPane, BorderLayout.CENTER);

        JMenuBar menuBar = criarBarraMenus();
        setJMenuBar(menuBar);

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                sair();
            }
        });

        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);

        pack();
        setLocationRelativeTo(null);

        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setVisible(true);
    }

    private JMenuBar criarBarraMenus() {
        
        JMenuBar menuBar = new JMenuBar();

        menuBar.add(criarMenuTelefone());
        menuBar.add(criarMenuOpcoes());

        return menuBar;
    }

    private JMenu criarMenuTelefone() {
        
        JMenu menu = new JMenu("Telefone");
        menu.setMnemonic(KeyEvent.VK_T);

        menu.add(criarItemNovoTelefone());

        menuItemEliminar = criarItemEliminarTelefone();
        menu.add(menuItemEliminar);

        menu.addSeparator();
        menu.add(criarSubMenuLista());
        menu.addSeparator();
        menu.add(criarItemSair());

        return menu;
    }

    private JMenuItem criarItemNovoTelefone() {
        
        JMenuItem item = new JMenuItem("Novo", KeyEvent.VK_N);
        item.setAccelerator(
                KeyStroke.getKeyStroke(KeyEvent.VK_N,InputEvent.CTRL_MASK));
        
        item.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                
                new DialogoNovoTelefone(Janela.this, listaTelefonica, tabPane);
                updateListaTelefonicaView();
            }
        });

        return item;
    }

    private JMenuItem criarItemEliminarTelefone() {
        
        JMenuItem item = new JMenuItem("Eliminar", KeyEvent.VK_E);
        item.setAccelerator(
                KeyStroke.getKeyStroke(KeyEvent.VK_E,InputEvent.CTRL_MASK));

        boolean tabelaPreenchida = 
                tableListaTelefonica.getModel().getRowCount() != 0;
        item.setEnabled(tabelaPreenchida);

        item.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                RemoverTelefoneController controller
                        = new RemoverTelefoneController(listaTelefonica);
                Telefone[] opcoes = controller.getListaTelefonesAsArray();

                Telefone telefone = (Telefone) JOptionPane.showInputDialog(
                        Janela.this,
                        "Escolha um telefone:", "Eliminar Telefone",
                        JOptionPane.PLAIN_MESSAGE,
                        null,
                        opcoes,
                        opcoes[0]);
                
                if (telefone != null) {
                    
                    String[] opcoes2 = {"Sim", "Não"};
                    
                    int resposta = JOptionPane.showOptionDialog(
                            Janela.this,
                            "Eliminar\n" + telefone.toString(),
                            "Eliminar Telefone",
                            0,
                            JOptionPane.QUESTION_MESSAGE,
                            null,
                            opcoes2,
                            opcoes2[1]);
                    
                    final int SIM = 0;
                    if (resposta == SIM) {
                        
                        if (controller.removeTelefone(telefone)) {

                            final int TAB_LISTA_TELEFONICA = 1;
                            tabPane.setSelectedIndex(TAB_LISTA_TELEFONICA);

                        } else {
                            JOptionPane.showMessageDialog(
                                    Janela.this,
                                    "Telefone não eliminado.",
                                    "Eliminar",
                                    JOptionPane.ERROR_MESSAGE);
                        }
                        
                        updateListaTelefonicaView();
                    }
                }
            }
        });

        return item;
    }

    private JMenu criarSubMenuLista() {
        
        JMenu menu = new JMenu("Lista");
        menu.setMnemonic(KeyEvent.VK_L);

        menu.add(criarItemImportarLista());
        
        menuItemExportarLista = criarItemExportarLista();
        menu.add(menuItemExportarLista);

        MyJFileChooser.personalizarFileChooserEmPortugues();
        fileChooser = new MyJFileChooser();

        return menu;
    }

    private JMenuItem criarItemImportarLista() {
        
        JMenuItem item = new JMenuItem("Importar", KeyEvent.VK_I);
        item.setAccelerator(
                KeyStroke.getKeyStroke(KeyEvent.VK_I, InputEvent.CTRL_MASK));
        
        item.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                int resposta = fileChooser.showOpenDialog(Janela.this);

                if (resposta == JFileChooser.APPROVE_OPTION) {
                    
                    ImportarListaTelefonicaController controller
                            = new ImportarListaTelefonicaController(listaTelefonica);
                    
                    File file = fileChooser.getSelectedFile();

                    int totalTelefonesAdicionados
                            = controller.importarListaTelefonica(file.getPath());

                    if (totalTelefonesAdicionados == -1) {
                        JOptionPane.showMessageDialog(
                                Janela.this,
                                "Impossível ler o ficheiro: " + file.getPath() + " !",
                                "Importar",
                                JOptionPane.ERROR_MESSAGE);
                    } else {
                        updateListaTelefonicaView();
                        
                        JOptionPane.showMessageDialog(
                                Janela.this,
                                "Registos importados: " + totalTelefonesAdicionados,
                                "Importar Lista Telefónica",
                                JOptionPane.INFORMATION_MESSAGE);
                    }
                }
            }
        });

        return item;
    }

    private JMenuItem criarItemExportarLista() {
        
        JMenuItem item = new JMenuItem("Exportar", KeyEvent.VK_X);
        item.setAccelerator(
                KeyStroke.getKeyStroke(KeyEvent.VK_X, InputEvent.CTRL_MASK));

        boolean tabelaPreenchida = 
                tableListaTelefonica.getModel().getRowCount() != 0;
        item.setEnabled(tabelaPreenchida);

        item.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                int resposta = fileChooser.showSaveDialog(Janela.this);
                
                if (resposta == JFileChooser.APPROVE_OPTION) {
                    
                    File file = fileChooser.getSelectedFile();
                    
                    if (!file.getName().endsWith(".bin")) {
                        file = new File(file.getPath().trim() + ".bin");
                    }

                    ExportarListaTelefonicaController controller
                            = new ExportarListaTelefonicaController();

                    boolean ficheiroGuardado
                            = controller.exportarListaTelefonica(
                                    file.getPath(),
                                    listaTelefonica);
                    
                    if (!ficheiroGuardado) {
                        JOptionPane.showMessageDialog(
                                Janela.this,
                                "Impossível gravar o ficheiro: "
                                + file.getPath() + " !",
                                "Exportar",
                                JOptionPane.ERROR_MESSAGE);
                    } else {
                        JOptionPane.showMessageDialog(
                                Janela.this,
                                "Ficheiro gravado com sucesso.",
                                "Exportar",
                                JOptionPane.INFORMATION_MESSAGE);
                    }
                }
            }
        });

        return item;
    }

    private JMenuItem criarItemSair() {
        
        JMenuItem item = new JMenuItem("Sair", KeyEvent.VK_S);
        item.setAccelerator(
                KeyStroke.getKeyStroke(KeyEvent.VK_S, InputEvent.ALT_MASK));
        
        item.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                sair();
            }
        });

        return item;
    }

    private JMenu criarMenuOpcoes() {
        
        JMenu menu = new JMenu("Opções");
        menu.setMnemonic(KeyEvent.VK_O);

        menu.add(criarSubMenuEstilo());
        menu.addSeparator();
        menu.add(criarItemAcerca());

        return menu;
    }

    private JMenu criarSubMenuEstilo() {
        
        JMenu menu = new JMenu("Estilo");
        menu.setMnemonic(KeyEvent.VK_E);

        for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
            menu.add(criarItemEstilo(info));
        }

        return menu;
    }

    private JMenuItem criarItemEstilo(UIManager.LookAndFeelInfo info) {
        
        JMenuItem item = new JMenuItem(info.getName());

        item.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                
                JMenuItem menuItem = (JMenuItem) e.getSource();
                try {
                    for (UIManager.LookAndFeelInfo info
                            : UIManager.getInstalledLookAndFeels()) {
                        if (menuItem.getActionCommand().equals(info.getName())) {
                            UIManager.setLookAndFeel(info.getClassName());
                            break;
                        }
                    }
                    SwingUtilities.updateComponentTreeUI(Janela.this);
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(
                            Janela.this,
                            ex.getMessage(),
                            "Estilo " + menuItem.getActionCommand(),
                            JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        return item;
    }

    private JMenuItem criarItemAcerca() {
        
        JMenuItem item = new JMenuItem("Acerca", KeyEvent.VK_A);
        item.setAccelerator(
                KeyStroke.getKeyStroke(KeyEvent.VK_A, InputEvent.CTRL_MASK));
        
        item.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                
                JOptionPane.showMessageDialog(
                        Janela.this,
                        "@Copyright\nESOFT-PPROG\n2014/2015",
                        "Acerca",
                        JOptionPane.INFORMATION_MESSAGE);
            }
        });
        return item;
    }

    private JTabbedPane criarSeparadores() {
        
        JTabbedPane tabPane = new JTabbedPane();
        tabPane.addTab("Início", new PainelInicio());

        PainelListaTelefonica pListaTelefonica
                = new PainelListaTelefonica(listaTelefonica, this);
        tabPane.addTab("Lista Telefónica", pListaTelefonica);

        tableListaTelefonica = pListaTelefonica.getTableListaTelefonica();

        ModeloTabelaListaTelefonica modeloTabela
                = (ModeloTabelaListaTelefonica) tableListaTelefonica.getModel();
        
        modeloTabela.addTableModelListener(new TableModelListener() {
            @Override
            public void tableChanged(TableModelEvent e) {
                boolean tabelaPreenchida
                        = tableListaTelefonica.getModel().getRowCount() != 0;
                menuItemEliminar.setEnabled(tabelaPreenchida);
                menuItemExportarLista.setEnabled(tabelaPreenchida);
            }
        });

        return tabPane;
    }

    private void sair() {

        ExportarListaTelefonicaController controller
                = new ExportarListaTelefonicaController();

        boolean listaTelefonicaGuardada
                = controller.exportarListaTelefonica(listaTelefonica);
        
        if (!listaTelefonicaGuardada) {
            JOptionPane.showMessageDialog(
                    Janela.this,
                    "Impossível guardar lista telefónica!",
                    "Sair",
                    JOptionPane.ERROR_MESSAGE);
        }
        dispose();
    }

    private void updateListaTelefonicaView() {
        
        ModeloTabelaListaTelefonica modeloTabelaListaTelefonica
                = (ModeloTabelaListaTelefonica) tableListaTelefonica.getModel();
        
        modeloTabelaListaTelefonica.refresh();
    }

}
