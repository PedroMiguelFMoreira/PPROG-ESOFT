package listatelefonica.controllers;

import listatelefonica.model.ListaTelefonica;
import listatelefonica.model.FicheiroListaTelefonica;

public class ExportarListaTelefonicaController {

    private FicheiroListaTelefonica ficheiro;

    public ExportarListaTelefonicaController() {
        this.ficheiro = new FicheiroListaTelefonica();
    }

    public boolean exportarListaTelefonica(ListaTelefonica listaTelefonica) {
        return this.ficheiro.guardar(listaTelefonica);
    }

    public boolean exportarListaTelefonica(
            String nomeFicheiro,
            ListaTelefonica listaTelefonica) {
        
        return this.ficheiro.guardar(nomeFicheiro, listaTelefonica);
    }
}
